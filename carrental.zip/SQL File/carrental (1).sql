-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 07:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4', '2024-05-01 12:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `BookingNumber` bigint(12) DEFAULT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `LastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `PaymentMethod` enum('Credit Card','Online Payment','Cash on Delivery') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `BookingNumber`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`, `LastUpdationDate`, `PaymentMethod`) VALUES
(1, 443108139, 'amikt12@gmail.com', 2, '2024-06-08', '2024-06-10', 'I want booking', 2, '2024-06-05 05:32:39', '2025-04-16 02:08:12', NULL),
(8, 563494919, 'syfqhchu@gmail.com', 1, '2025-04-13', '2025-04-13', 'test', 1, '2025-04-13 07:31:58', '2025-04-13 07:32:21', 'Credit Card'),
(9, 651687421, 'syfqhchu@gmail.com', 2, '2025-04-13', '2025-04-16', 'test2', 1, '2025-04-13 07:34:56', '2025-04-14 06:22:52', 'Credit Card'),
(10, 293726776, 'syfqhchu@gmail.com', 1, '2025-04-14', '2025-04-14', 'test cancel', 2, '2025-04-14 06:16:16', '2025-04-14 06:16:37', 'Credit Card'),
(11, 957493387, 'norazlin@gmail.com', 2, '2025-04-17', '2025-04-17', 'want book', 2, '2025-04-16 02:06:05', '2025-04-16 02:09:03', 'Credit Card'),
(12, 320758078, 'jalilwongso97@gmail.com', 5, '2025-04-16', '2025-04-19', 'I want to book this car', 1, '2025-04-16 02:49:16', '2025-04-19 15:11:01', 'Credit Card'),
(13, 665151308, 'arienazis@gmail.com', 6, '2025-04-21', '2025-04-23', 'hi, i want to book this car', 2, '2025-04-16 03:18:34', '2025-04-19 15:11:01', 'Credit Card'),
(14, 737908123, 'xoxoluv.na@gmail.com', 2, '2025-04-19', '2025-04-20', 'i want to book', 1, '2025-04-19 13:19:02', '2025-04-19 13:36:09', 'Credit Card'),
(15, 699019423, 'chryeaa@gmail.com', 3, '2025-04-19', '2025-04-21', 'i want to book', 1, '2025-04-19 13:24:39', '2025-04-19 15:11:01', 'Credit Card'),
(16, 963250446, 'zalqiszainuddin@gmail.com', 2, '2025-05-02', '2025-05-06', 'i want to book ', 1, '2025-04-19 13:29:12', '2025-04-19 15:11:01', 'Credit Card'),
(17, 968032108, 'alifjalil515@gmail.com', 8, '2025-04-21', '2025-04-24', 'hi, i want to book this car', 1, '2025-04-19 13:41:51', '2025-04-19 15:11:01', 'Credit Card'),
(18, 447998889, 'alifjalil515@gmail.com', 3, '2025-04-26', '2025-04-29', 'i want to book again', 0, '2025-04-19 13:44:04', '2025-04-19 15:11:01', 'Credit Card'),
(19, 645121831, 'nurainiffahaqilah@gmail.com', 1, '2025-04-19', '2025-04-22', 'i want to book', 0, '2025-04-19 13:59:37', NULL, 'Credit Card'),
(20, 607300285, 'dayahmuhammad@gmail.com', 2, '2025-04-21', '2025-04-23', 'i want to book', 0, '2025-04-19 14:15:20', '2025-04-19 15:11:01', 'Credit Card'),
(21, 837674992, 'nrfatihahjeff@gmail.com', 4, '2025-04-27', '2025-04-30', 'i want to book this car', 2, '2025-04-19 16:56:06', '2025-04-19 16:59:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Maruti', '2024-05-01 16:24:34', '2024-06-05 05:26:25'),
(2, 'BMW', '2024-05-01 16:24:34', '2024-06-05 05:26:34'),
(3, 'Audi', '2024-05-01 16:24:34', '2024-06-05 05:26:34'),
(4, 'Nissan', '2024-05-01 16:24:34', '2024-06-05 05:26:34'),
(5, 'Toyota', '2024-05-01 16:24:34', '2024-06-05 05:26:34'),
(7, 'Volkswagon', '2024-05-01 16:24:34', '2024-06-05 05:26:34');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'J&K Block, Laxmi Nagar', 'wheeliocarrentalinfo@gmail.com', '8974561236');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Kunal ', 'kunal@gmail.com', '7977779798', 'I want to know you brach in Chandigarh?', '2024-06-04 09:34:51', 1),
(2, 'syafiqah', 'syfqhchu@gmail.com', '1157159112', 'terbaik dan murah', '2025-04-13 09:09:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'Terms and Conditions', 'terms', '<P align=\"justify\">\r\n  <FONT size=\"2\">\r\n    <STRONG><FONT color=\"#990000\">(1) ACCEPTANCE OF TERMS</FONT><BR><BR></STRONG>\r\n    Welcome to Wheelio Car Rental. Wheelio Car Rental, \"we\" or \"us,\" provides the car rental service (the \"Service\") to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time on our website. In addition, when using particular services or third-party services, you and Wheelio shall be subject to any posted guidelines or rules applicable to such services, which may be updated from time to time. All such guidelines or rules, which may be subject to change, are hereby incorporated by reference into the TOS. In the event of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Service, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Service.\r\n  </FONT>\r\n</P>\r\n\r\n<P align=\"justify\">\r\n  <FONT size=\"2\">\r\n    In addition, when using particular Wheelio Car Rental services or third-party services, you and Wheelio shall be subject to any posted guidelines or rules applicable to such services. These guidelines or rules may change over time, and all such changes will be incorporated into the TOS. In case of any conflict between the TOS and these guidelines or rules, the TOS will prevail.\r\n  </FONT>\r\n</P>\r\n\r\n<P align=\"justify\">\r\n  <FONT size=\"2\">\r\n    We may also offer additional services from time to time that are governed by different Terms of Service, in which case these TOS will not apply to such services if and to the extent expressly excluded by such different Terms of Service.\r\n  </FONT>\r\n</P>\r\n'),
(2, 'Privacy Policy', 'privacy', '<span style=\"color: rgb(0, 0, 0); font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; text-align: justify;\">\r\nAt Wheelio Car Rental, we offer a wide range of vehicles to meet all your travel needs. Whether you\'re looking for a compact car for a city trip, a luxury vehicle for a special occasion, or a spacious SUV for a family road trip, we have you covered. Our fleet is regularly maintained to ensure safety, comfort, and reliability on the road. With flexible rental options and affordable pricing, you can enjoy a seamless experience from pick-up to drop-off. We pride ourselves on excellent customer service and offer convenient online booking, ensuring you get the car you need, when you need it. Trust Wheelio Car Rental for your next adventure, and experience travel with ease and convenience.\r\n</span>\r\n'),
(3, 'About Us ', 'aboutus', '<span style=\"color: rgb(51, 51, 51); font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\nWe offer a diverse fleet of cars, ranging from compact vehicles to larger models. All our cars are equipped with air conditioning, power steering, and electric windows for your comfort. We purchase and maintain our vehicles exclusively from official dealerships to ensure high quality and reliability. Additionally, automatic transmission cars are available across all booking categories.\r\n</span>\r\n<span style=\"color: rgb(52, 52, 52); font-family: Arial, Helvetica, sans-serif; font-size: 16px;\">\r\nSince we are not tied to any single automaker, we can offer a wide range of makes and models to meet the preferences of all our customers.\r\n</span>\r\n<div>\r\n  <span style=\"color: rgb(62, 62, 62); font-family: \'Lucida Sans Unicode\', \'Lucida Grande\', sans-serif; font-size: 14px;\">\r\n    Our mission is to be recognized as the global leader in car rental services, catering to both companies and the public/private sectors. By partnering with our clients, we aim to provide the best and most efficient rental solutions, all while achieving service excellence.\r\n  </span>\r\n  <span style=\"color: rgb(52, 52, 52); font-family: Arial, Helvetica, sans-serif; font-size: 16px;\">\r\n    <br>\r\n  </span>\r\n</div>\r\n'),
(11, 'FAQs', 'faqs', '<span style=\"color: rgb(0, 0, 0); font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; text-align: justify;\">\r\n1. Is there a minimum age requirement?<br>\r\nYes, renters must be at least 23 years old and have a valid license for at least 1 year. For luxury vehicles, the minimum age requirement is 26.<br>\r\n2. What is your cancellation policy?<br>\r\nCancellations made at least 48 hours before pickup are free of charge. Cancellations within 48 hours may incur a small fee.<br>\r\n3.What if I return the car late?<br>\r\nLate returns will be charged hourly. If you expect a delay, please notify us early to avoid inconvenience.\r\n</span>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayments`
--

CREATE TABLE `tblpayments` (
  `id` int(11) NOT NULL,
  `BookingId` int(11) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `PaymentMethod` enum('Credit Card','Online Payment','Cash on Delivery') NOT NULL,
  `TransactionId` varchar(100) DEFAULT NULL,
  `PaymentStatus` varchar(50) DEFAULT NULL,
  `PaymentDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblsubscribers`
--

INSERT INTO `tblsubscribers` (`id`, `SubscriberEmail`, `PostingDate`) VALUES
(4, 'harish@gmail.com', '2024-06-01 09:26:21'),
(5, 'kunal@gmail.com', '2024-05-31 09:35:07'),
(6, 'syfqhchu@gmail.com', '2025-04-13 13:58:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbltestimonial`
--

CREATE TABLE `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbltestimonial`
--

INSERT INTO `tbltestimonial` (`id`, `UserEmail`, `Testimonial`, `PostingDate`, `status`) VALUES
(1, 'syfqhchu@gmail.com', 'woww', '2025-04-13 09:42:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(2, 'Amit', 'amikt12@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '1425365214', NULL, NULL, NULL, NULL, '2024-06-05 05:31:05', NULL),
(3, 'Nurul Syafiqah binti Jalil', 'syfqhchu@gmail.com', '202cb962ac59075b964b07152d234b70', '01157159112', '21/02/2005', 'Taman Desa Idaman, No.67, Jalan Di 17, Taman Desa Idaman', 'Durian Tunggal', 'Durian Tunggal', '2025-04-10 18:56:46', '2025-04-19 12:48:34'),
(4, 'Azlin', 'norazlin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '12457689', NULL, NULL, NULL, NULL, '2025-04-16 02:05:15', NULL),
(5, 'Jalil bin Jamingan', 'jalilwongso97@gmail.com', 'bd9214a5d651a15aa540c1acdf665394', '0195551032', '5/3/1997', 'No.67, Taman Desa Idaman, Durian Tunggal', 'Melaka', 'Malaysia', '2025-04-16 02:48:23', '2025-04-16 03:14:22'),
(6, 'Arien binti Akhtar Azis', 'arienazis@gmail.com', '6610d2e6adaa2b0f3591f70694fc75a6', '0187672467', '21/08/1975', 'No.67, Taman Desa Idaman, Durian Tunggal', 'Melaka', 'Malaysia', '2025-04-16 03:16:00', '2025-04-16 03:17:50'),
(8, 'Nurul Husna binti Mohd Shariff', 'xoxoluv.na@gmail.com', 'e13dd027be0f2152ce387ac0ea83d863', '0173590647', '19/4/2004', 'PPR Pudu Ulu, 56100, Cheras, KL\r\n', 'Kuala Lumpur', 'Malaysia', '2025-04-19 13:14:28', '2025-04-19 13:16:34'),
(9, 'nur fatin nabilah binti mohd shahril', 'chryeaa@gmail.com', '2bebdf92d14f5577e57a09231616fe49', '1121082532', '19/4/2004', '1352, JALAN POLITEKNIK 25, TAMAN POLITEKNIK, 71050, PORT DICKSON, NEGERI SEMBILAN', 'PORT DICKSON', 'Malaysia', '2025-04-19 13:21:11', '2025-04-19 13:34:01'),
(10, 'AMEERA ZALQIS BINTI ZAINUDDIN', 'zalqiszainuddin@gmail.com', 'b83a886a5c437ccd9ac15473fd6f1788', '0192222366', '29092005', 'NO 5, JALAN SRI SULONG 19, TAMAN INDUSTRI SRI SULONG, BATU PAHAT,83500, JOHOR', 'JOHOR', 'BATU PAHAT', '2025-04-19 13:26:17', '2025-04-19 13:33:12'),
(11, 'Muhd Alif Ekmal', 'alifjalil515@gmail.com', '5578411c4868b58aa65f7fb1f2e1a26f', '0143962877', '16/10/2005', 'No.67, Taman Desa Idaman, Durian Tunggal', 'Melaka', 'Melaka', '2025-04-19 13:40:16', '2025-04-19 13:41:10'),
(12, 'Nuraini Iffah Aqilah binti Jalil', 'nurainiffahaqilah@gmail.com', '25f9e794323b453885f5181f1b624d0b', '0123962372', '03/05/2009', 'No.67, Taman Desa Idaman, Durian Tunggal', 'Melaka', 'Melaka', '2025-04-19 13:56:55', '2025-04-19 13:57:56'),
(13, 'Nurul Hidayah binti Muhammad', 'dayahmuhammad@gmail.com', '51fd5a8a3aa3a6e6bad2f456f665ee83', '0116324953', '17/07/2004', '22381, Jalan Puah 3rd Mile, Kampung Puah, 53000 Kuala Lumpur', 'Kuala Lumpur', 'Malaysia', '2025-04-19 14:13:56', '2025-04-19 14:40:18'),
(14, 'Nur Fatihah binti Jeffrinih', 'nrfatihahjeff@gmail.com', '43be622c6deb12c85fd7550614f3a224', '0136739478', '21/11/2004', 'Blok A8, Tingkat 1, pintu 4, PGA Batalion 17, Jalan Silam, Lahad Datu, Sabah', 'Sabah', 'Malaysia', '2025-04-19 16:53:50', '2025-04-19 16:57:42');

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `id` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(1, 'Maruti Suzuki Wagon R', 1, 'The Maruti Wagon R is a smart and fuel-efficient choice for city and long-distance travel. Powered by a BS6-compliant 1.0-litre engine, it delivers 68PS of power and 90Nm of torque, ensuring a smooth and responsive driving experience. With its impressive fuel efficiency of 21.79 km/l and optional CNG variant offering up to 32.52 km/kg, it’s ideal for budget-conscious and eco-friendly drivers alike.\r\n\r\nThis vehicle is part of Maruti Suzuki’s ‘Mission Green Million’ initiative, making it a great choice for those who value sustainability without compromising on performance. Spacious, reliable, and practical, the Wagon R is well-suited for both individual travelers and families.\r\n\r\nRental Rate: RM500 per day', 500, 'Petrol', 2019, 5, 'rear-3-4-left-589823254_930x620.jpg', 'tail-lamp-1666712219_930x620.jpg', 'rear-3-4-right-520328200_930x620.jpg', 'steering-close-up-1288209207_930x620.jpg', 'boot-with-standard-luggage-202327489_930x620.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2025-04-11 02:41:49'),
(2, 'BMW 5 Series', 2, 'BMW 5 Series – Luxury Meets Performance\r\n\r\nThe BMW 5 Series is the perfect blend of power, elegance, and innovation. In Malaysia, the 5 Series is priced between RM400,000 and RM490,000, depending on the model and specifications. It is available in both petrol and diesel variants, offering a balance of refined comfort and robust performance to suit different driving preferences.\r\n\r\nRenowned for its cutting-edge technology, luxurious interiors, and commanding road presence, the BMW 5 Series is a top choice for those seeking a premium driving experience. Whether for corporate travel, special occasions, or a weekend escape, it promises unmatched comfort, prestige, and performance.\r\n\r\nRental Rate: RM1000 per day', 1000, 'Petrol', 2018, 5, 'BMW-5-Series-Exterior-102005.jpg', 'BMW-5-Series-New-Exterior-89729.jpg', 'BMW-5-Series-Exterior-102006.jpg', 'BMW-5-Series-Interior-102021.jpg', 'BMW-5-Series-Interior-102022.jpg', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, 1, '2024-05-10 07:04:35', '2025-04-11 02:45:28'),
(3, 'Audi Q8', 3, 'As per ARAI, the mileage of Q8 is 0 kmpl. Real mileage of the vehicle varies depending upon the driving habits. City and highway mileage figures also vary depending upon the road conditions.', 3000, 'Petrol', 2017, 5, 'audi-q8-front-view4.jpg', '1920x1080_MTC_XL_framed_Audi-Odessa-Armaturen_Spiegelung_CC_v05.jpg', 'audi1.jpg', '1audiq8.jpg', 'audi-q8-front-view4.jpeg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(4, 'Nissan Kicks', 4, 'Latest Update: Nissan has launched the Kicks 2020 with a new turbocharged petrol engine. You can read more about it here.\r\n\r\nNissan Kicks Price and Variants: The Kicks is available in four variants: XL, XV, XV Premium, and XV Premium(O).', 800, 'Petrol', 2020, 5, 'front-left-side-47.jpg', 'kicksmodelimage.jpg', 'download.jpg', 'kicksmodelimage.jpg', '', 1, NULL, NULL, 1, NULL, NULL, 1, 1, NULL, NULL, NULL, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(5, 'Nissan GT-R', 4, ' The GT-R packs a 3.8-litre V6 twin-turbocharged petrol, which puts out 570PS of max power at 6800rpm and 637Nm of peak torque. The engine is mated to a 6-speed dual-clutch transmission in an all-wheel-drive setup. The 2+2 seater GT-R sprints from 0-100kmph in less than 3', 2000, 'Petrol', 2019, 5, 'Nissan-GTR-Right-Front-Three-Quarter-84895.jpg', 'Best-Nissan-Cars-in-India-New-and-Used-1.jpg', '2bb3bc938e734f462e45ed83be05165d.jpg', '2020-nissan-gtr-rakuda-tan-semi-aniline-leather-interior.jpg', 'images.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(6, 'Nissan Sunny 2020', 4, 'Value for money product and it was so good It is more spacious than other sedans It looks like a luxurious car.', 400, 'CNG', 2018, 5, 'Nissan-Sunny-Right-Front-Three-Quarter-48975_ol.jpg', 'images (1).jpg', 'Nissan-Sunny-Interior-114977.jpg', 'nissan-sunny-8a29f53-500x375.jpg', 'new-nissan-sunny-photo.jpg', 1, 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(7, 'Toyota Fortuner', 5, 'Toyota Fortuner Features: It is a premium seven-seater SUV loaded with features such as LED projector headlamps with LED DRLs, LED fog lamp, and power-adjustable and foldable ORVMs. Inside, the Fortuner offers features such as power-adjustable driver seat, automatic climate control, push-button stop/start, and cruise control.\r\n\r\nToyota Fortuner Safety Features: The Toyota Fortuner gets seven airbags, hill assist control, vehicle stability control with brake assist, and ABS with EBD.', 3000, 'Petrol', 2020, 5, '2015_Toyota_Fortuner_(New_Zealand).jpg', 'toyota-fortuner-legender-rear-quarters-6e57.jpg', 'zw-toyota-fortuner-2020-2.jpg', 'download (1).jpg', '', NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(8, 'Maruti Suzuki Vitara Brezza', 1, 'The new Vitara Brezza is a well-rounded package that is feature-loaded and offers good drivability. And it is backed by Maruti’s vast service network, which ensures a peace of mind to customers. The petrol motor could have been more refined and offered more pep.', 600, 'Petrol', 2018, 5, 'marutisuzuki-vitara-brezza-right-front-three-quarter3.jpg', 'marutisuzuki-vitara-brezza-rear-view37.jpg', 'marutisuzuki-vitara-brezza-dashboard10.jpg', 'marutisuzuki-vitara-brezza-boot-space59.jpg', 'marutisuzuki-vitara-brezza-boot-space28.jpg', NULL, 1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, 1, NULL, '2024-05-10 07:04:35', '2024-06-05 05:30:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpayments`
--
ALTER TABLE `tblpayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `BookingId` (`BookingId`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`);

--
-- Indexes for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblpayments`
--
ALTER TABLE `tblpayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblpayments`
--
ALTER TABLE `tblpayments`
  ADD CONSTRAINT `tblpayments_ibfk_1` FOREIGN KEY (`BookingId`) REFERENCES `tblbooking` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
